package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.User;
import com.niit.shoppingcart.model.User;

public class UserTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.niit.shoppingcart");
	context.refresh();
	UserDAO userDAO = (UserDAO) context.getBean("userDAO");
	User user = (User) context.getBean("user");
	user.setId("id02");
	user.setName("rahul");
	user.setPassword("123");
	user.setMobileno("123456789");
	user.setMail("gmail.com");
	user.setAddress("malleshwaram");
	user.setAdmin((byte) 0);
	userDAO.saveOrUpdate(user);
	if (userDAO.get("ssdf")==null)
	{
		System.out.println("user doesnt exist");
	}
	else
	{
		System.out.println("user exist");
	}
	
	
	
	}
}

package com.niit.shoppingcart.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CartDAO;
import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.UserDAO;
import com.niit.shoppingcart.model.Cart;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.User;

@Controller
public class UserController {
	
	@Autowired
	private UserDAO userDAO;
	
	@Autowired
	User user;
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private Category category;
	
	@Autowired
	private Cart cart;
	
	@Autowired
	private CartDAO cartDAO;
	
	
@RequestMapping("/")
public ModelAndView onLoad(HttpSession session)
{
	ModelAndView mv = new ModelAndView ("/index");
	session.setAttribute("category", category);
	session.setAttribute("categoryList", categoryDAO.list());
	System.out.println("landing page");
	return mv;
}
	
//	@RequestMapping("/")
//	public String getLanding()
//	{
//		System.out.println("Get Landing.....");
//		return "index";
//	}
@RequestMapping("/aboutus")
public String about()
{
	return "aboutus";
}
@RequestMapping("/contactus")
public String contact()
{
	return "contactus";
}
@RequestMapping("/home")
public String home()
{
	return "home";
}
//@RequestMapping("/login")
//public String login()
//{
//	return "login";
//}
	
//	@RequestMapping("/check")
//	public ModelAndView login(@RequestParam (name="name")String id,@RequestParam (name="password")String password)
//	{
//		ModelAndView mv = new ModelAndView("/adminHome");
//		boolean isValidUser = userDAO.isValidUser (id, password);
//		if (isValidUser == true)
//		{
//			user = userDAO.get(id);
//			
//			if (user.getAdmin()==1)
//			{
//				mv=new ModelAndView("/adminHome");
//				mv.addObject("admin", "true");
//			}
//			else
//			{
//
//				mv=new ModelAndView("/index");
//				mv.addObject("message", "welcome"+user.getName());
//				   cart = cartDAO.getCart(id);
//			     				mv.addObject("cart", cart);
//			       				List<Cart> cartList = cartDAO.list(id);
//		         				mv.addObject("cartList", cartList);
//		           				mv.addObject("cartSize", cartList.size());
//			}}
//				else
//			{
//				mv.addObject("invalid credentials", "true");
//				mv.addObject("error Message", "invalid credentials");
//			}
//		
//		return mv;
//	}


@RequestMapping("/signup")
public ModelAndView signup(){
	ModelAndView mv=new ModelAndView("/index");
	mv.addObject("user",user);
	mv.addObject("isUserClickedRegisterHere", "true");
	return mv;
}
@RequestMapping(value = "/loginUser")
public String login(@RequestParam(value="error", required = false) String error, @RequestParam(value="logout",
        required = false) String logout, Model model) {
    if (error!=null) {
    	System.out.println("Error.....");
        model.addAttribute("error", "...Invalid username and password");
    }
    	
    if(logout!=null) {
    	System.out.println("Logout called.....");
        model.addAttribute("msg", "...You have been logged out");
    }

    return "login";
} @RequestMapping(value = "/user")
public String userManagement() 
{
	System.out.println("USER CALLED.......");
	return "login";
}

@RequestMapping(value = "/admin")
public String adminManagement() 
{
	System.out.println("ADMIN CALLED.......");
	return "adminHome";
}

@RequestMapping(value="/afterLogin", method = RequestMethod.GET)
public String afterLogint() 
{
	System.out.println("After User Login.......");
	return "afterLoginUser";
}

@RequestMapping("/403")
public String errorPage() 
{
	System.out.println("Error......");
	return "403";
	
}
@RequestMapping("/payment")
public String payment()
{
	return "payment";
}
@RequestMapping("/thanks")
public String thanks()
{
	return "thanks";
}
}
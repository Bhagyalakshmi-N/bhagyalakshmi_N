package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.model.Product;

public class ProductTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
	context.scan("com.niit.shoppingcart");
	context.refresh();
	ProductDAO productDAO = (ProductDAO) context.getBean("productDAO");
	Product product = (Product) context.getBean("product");
	product.setId("id003");
	product.setName("mobile");
	product.setDescription("android");
	product.setPrice(10000);
	productDAO.saveOrUpdate(product);
	if (productDAO.get("ssdf")==null)
	{
		System.out.println("product doesnt exist");
	}
	else
	{
		System.out.println("product exist");
	}
	
	
	
	}
}

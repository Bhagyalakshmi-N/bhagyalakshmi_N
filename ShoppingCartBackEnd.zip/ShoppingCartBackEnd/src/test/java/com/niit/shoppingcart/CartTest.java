package com.niit.shoppingcart;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcart.dao.CartDAO;

import com.niit.shoppingcart.model.Cart;

public class CartTest {

	public static void main(String[] args) {
		
AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

	context.scan("com.niit.shoppingcart");
	context.refresh();
	
	Cart cart = (Cart)context.getBean("cart");
	System.out.println("succesfully created");
	
	CartDAO cartDAO = (CartDAO)context.getBean("cartDAO");
	cart.setId(001);;
	cart.setPrice(25000);
	cart.setProductName("FastTrack");
	cart.setQuantity(2);
	cart.setStatus('Y');
	cart.setUserID("US_001");
	cart.setTotal(50000);
	
	

		cartDAO.saveOrUpdate(cart);
	}

}
